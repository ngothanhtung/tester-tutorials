INSERT INTO [dbo].[Customers]
(
    [Id],
    [FirstName],
    [LastName],
    [PhoneNumber],
    [Address],
    [Email],
    [Birthday]
)
VALUES
(
    '11',
    N'Hồ',
    N'Hiền',
    '0812037001',
    N'40 Hải Phòng',
    'hothithuhien@gmail.com',
    '1990-04-12 00:00:00.000'
);
INSERT INTO [dbo].[Customers]
(
    [Id],
    [FirstName],
    [LastName],
    [PhoneNumber],
    [Address],
    [Email],
    [Birthday]
)
VALUES
(
    '12',
    N'Hồ',
    N'Hiền',
    '0812037001',
    N'40 Hải Phòng',
    'hothithuhien1@gmail.com',
    '1993-08-12 00:00:00.000'
);
