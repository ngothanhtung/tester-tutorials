
INSERT INTO [Suppliers]
(
    [Name],
    [PhoneNumber],
    [Address],
    [Email]
)
VALUES
(
    N'Hiền',
    '0812307001',
    N'717 Tôn Đản',
    'hothithuhien12@gmail.com'

);
INSERT INTO [Suppliers]
(
    [Name],
    [PhoneNumber],
    [Address],
    [Email]
)
VALUES
(
    N'Hiền',
    '0812307001',
    N'717 Tôn Đản',
    'hothithuhien123@gmail.com'

);