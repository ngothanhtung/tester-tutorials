INSERT INTO [dbo].[Products]
(
   [Name],
   [Price],
   [Discount],
   [Stock],
   [Description],
   [CategoryId],
   [SupplierId]
)
VALUES
(
    N'Hiền',
    150,
    30,
    10,
    N'Màu đen',
    1068,
    1187
);