INSERT INTO [dbo].[Employees]
(
    [Id],
    [FirstName],
    [LastName],
    [PhoneNumber],
    [Address],
    [Email],
    [Birthday]
)
VALUES
(
    'CH1081',
    N'Hồ',
    N'Hiền',
    '0812037002',
    N'18 Hùng Vương[dbo].[Employees]',
    'hohien1234@gmail.com',
    '2014-08-12 00:00:00.000'
);