INSERT INTO [dbo].[OrderDetails]
(
  [OrderId],
  [ProductId],
  [Quantity],
  [Price],
  [Discount]
)
VALUES
(
    10000128,
    209400,
    0,
    1,
    91 
);