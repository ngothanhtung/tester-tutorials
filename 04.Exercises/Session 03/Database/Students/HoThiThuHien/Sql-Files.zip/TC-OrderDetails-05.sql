INSERT INTO [dbo].[OrderDetails]
(
  [OrderId],
  [ProductId],
  [Quantity],
  [Price],
  [Discount]
)
VALUES
(
    10000126,
    209396,
    100,
    1,
    91
   
);