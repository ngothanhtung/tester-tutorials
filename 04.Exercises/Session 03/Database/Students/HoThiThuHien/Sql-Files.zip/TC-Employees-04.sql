INSERT INTO [dbo].[Employees]
(
    [Id],
    [FirstName],
    [LastName],
    [PhoneNumber],
    [Address],
    [Email],
    [Birthday]
)
VALUES
(
    '1080',
    N'Hồ',
    N'Hiền',
    '0812037001',
    N'21 Phan Châu Trinh',
    'hohien@gmail.com',
    '1990-04-12 00:00:00.000'
);
INSERT INTO [dbo].[Customers]
(
    [Id],
    [FirstName],
    [LastName],
    [PhoneNumber],
    [Address],
    [Email],
    [Birthday]
)
VALUES
(
    '1081',
    N'Hồ',
    N'Hiền',
    '0812037001',
    N'21 Phan Châu Trinh',
    'hohien123@gmail.com',
    '1993-08-12 00:00:00.000'
);
