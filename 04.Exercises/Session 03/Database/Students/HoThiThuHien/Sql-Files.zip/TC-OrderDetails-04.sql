INSERT INTO [dbo].[OrderDetails]
(
  [OrderId],
  [ProductId],
  [Quantity],
  [Price],
  [Discount]
)
VALUES
(
    10000121,
    209403,
    0,
    0,
    91 
);