INSERT INTO [dbo].[Customers]
(
    [Id],
    [FirstName],
    [LastName],
    [PhoneNumber],
    [Address],
    [Email],
    [Birthday]
)
VALUES
(
    '13',
    N'Hồ',
    N'Hiền',
    '0812037001',
    N'40 Hải Phòng',
    'hothithuhien12@gmail.com',
    '2010-04-12 00:00:00.000'
);